package com.example.homework3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;




import java.io.File;
import java.lang.reflect.Type;

public class StudentSummary extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout Studentlayout = new LinearLayout(this);
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        Studentlayout.setLayoutParams(params);
        Studentlayout.setOrientation(LinearLayout.VERTICAL);

        LinearLayout fNameLayout = new LinearLayout(this);
        ViewGroup.LayoutParams NameParams = new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        );
        fNameLayout.setLayoutParams(NameParams);
        fNameLayout.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout lNameLayout = new LinearLayout(this);
        fNameLayout.setLayoutParams(NameParams);
        fNameLayout.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout IDLayout = new LinearLayout(this);
        fNameLayout.setLayoutParams(NameParams);
        fNameLayout.setOrientation(LinearLayout.HORIZONTAL);


        TextView tv = new TextView(this);
        tv.setText("Student Activity");
        Studentlayout.addView(tv);

        //FirstName widgets
        TextView fNameTV = new TextView(this);
        fNameTV.setText("First Name:");
        final EditText fNameText = new EditText(this);
        fNameLayout.addView(fNameTV);
        fNameLayout.addView(fNameText);
        Studentlayout.addView(fNameLayout);

        TextView lNameTV = new TextView(this);
        lNameTV.setText("Last Name:");
        final EditText lNameText = new EditText(this);
        lNameLayout.addView(lNameTV);
        lNameLayout.addView(lNameText);
        Studentlayout.addView(lNameLayout);

        TextView IDTV = new TextView(this);
        IDTV.setText("Student ID:");
        final EditText IDText = new EditText(this);
        IDText.setInputType(InputType.TYPE_CLASS_NUMBER);
        IDLayout.addView(IDTV);
        IDLayout.addView(IDText);
        Studentlayout.addView(IDLayout);


        Button addButton = new Button(this);

        addButton.setText("Add");

        Studentlayout.addView(addButton);


        addButton.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View view){
                        File studentDBFile = getApplicationContext().getDatabasePath("StudentDB");
                        SQLiteDatabase db = SQLiteDatabase.openOrCreateDatabase(studentDBFile, null);
                        //int studId = Integer.parseInt(IDText.getText().toString());

                        ContentValues values = new ContentValues();
                        values.put("FirstName", fNameText.getText().toString());
                        values.put("LastName", lNameText.getText().toString());
                        values.put("SID", Integer.parseInt(IDText.getText().toString()));
                        db.insert("Student", null, values);
                        db.close();

                    }
                }
        );



        //File studentDBFile = this.getDatabasePath("StudentDB");
        //SQLiteDatabase db = SQLiteDatabase.openOrCreateDatabase(studentDBFile, null);


        //db.close();



        setContentView(Studentlayout);
    }
}
