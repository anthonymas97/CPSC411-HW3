package com.example.homework3;

public class Course {
    protected String mCourseID;
    protected String mGrade;

    public Course(String id, String grade){
        mCourseID = id;
        mGrade = grade;
    }

    public String getCourseID() { return mCourseID; }

    public void setCourseID(String id){ mCourseID = id; }

    public String getGrade() { return mGrade; }

    public void setGrade(String grade) { mGrade = grade; }
}
