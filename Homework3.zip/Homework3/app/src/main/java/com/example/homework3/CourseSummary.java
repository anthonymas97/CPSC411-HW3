package com.example.homework3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.database.sqlite.SQLiteDatabase;
import java.io.File;


public class CourseSummary extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout Courselayout = new LinearLayout(this);
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        Courselayout.setLayoutParams(params);
        Courselayout.setOrientation(LinearLayout.VERTICAL);

        TextView tv = new TextView(this);
        tv.setText("Course Activity");
        Courselayout.addView(tv);

        LinearLayout courseIDLayout = new LinearLayout(this);
        courseIDLayout.setLayoutParams(params);
        courseIDLayout.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout gradeLayout = new LinearLayout(this);
        gradeLayout.setLayoutParams(params);
        gradeLayout.setOrientation(LinearLayout.HORIZONTAL);

        TextView courseTV = new TextView(this);
        courseTV.setText("Course ID:");
        final EditText courseText = new EditText(this);
        courseIDLayout.addView(courseTV);
        courseIDLayout.addView(courseText);
        Courselayout.addView(courseIDLayout);

        TextView gradeTV = new TextView(this);
        gradeTV.setText("Grade:");
        final EditText gradeText = new EditText(this);
        gradeLayout.addView(gradeTV);
        gradeLayout.addView(gradeText);
        Courselayout.addView(gradeLayout);

        Button addButton = new Button(this);
        addButton.setText("Add");
        Courselayout.addView(addButton);

        addButton.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View view){
                        File studentDBFile = getApplicationContext().getDatabasePath("StudentDB");
                        SQLiteDatabase db = SQLiteDatabase.openOrCreateDatabase(studentDBFile, null);
                        //int studId = Integer.parseInt(IDText.getText().toString());

                        ContentValues values = new ContentValues();
                        values.put("CourseId", courseText.getText().toString());
                        values.put("Grade", gradeText.getText().toString());
                        db.insert("Course", null, values);
                        db.close();

                    }
                }
        );
        setContentView(Courselayout);
    }
}
