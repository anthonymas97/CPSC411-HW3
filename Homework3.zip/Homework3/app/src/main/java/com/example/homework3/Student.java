package com.example.homework3;

import java.util.ArrayList;

public class Student {
    protected String mFirstName;
    protected String mLastName;
    protected int mStudentID;

    protected ArrayList<Course> mCourses;

    public Student(String fName, String lName, int id){
        mFirstName = fName;
        mLastName = lName;
        mStudentID = id;
    }

    public String getFirstName(){ return mFirstName; }

    public void setFirstName(String firstName) { mFirstName = firstName; }

    public String getLastName(){ return mLastName; }

    public void setLastName(String lastName) { mLastName = lastName; }

    public int getID() { return mStudentID; }

    public void setID(int id) { mStudentID = id; }

    public ArrayList<Course> getCourses() { return mCourses; }

    public void setCourses (ArrayList<Course> courses) { mCourses = courses; }
}
