package com.example.homework3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Create DataBase here
        File studentDBFile = this.getDatabasePath("StudentDB");
        SQLiteDatabase db = SQLiteDatabase.openOrCreateDatabase(studentDBFile, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS Student (FirstName TEXT, LastName TEXT, SID INTEGER)");

        db.close();






        LinearLayout layout = new LinearLayout(this);
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        layout.setLayoutParams(params);
        layout.setOrientation(LinearLayout.VERTICAL);

        Button addStudent = new Button(this);
        addStudent.setText("Add Student");
        addStudent.setGravity(Gravity.CENTER);

        Button addCourse = new Button(this);
        addCourse.setText("Add Course");

        layout.addView(addStudent);
        layout.addView(addCourse);

        addStudent.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View view){
                        Intent intent = new Intent(view.getContext(), StudentSummary.class);
                        //String message = "message";
                        view.getContext().startActivity(intent);

                    }
                }
        );

        addCourse.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View view){
                        Intent intent = new Intent(view.getContext(), CourseSummary.class);
                        //String message = "message";
                        view.getContext().startActivity(intent);

                    }
                }
        );





        setContentView(layout);
    }
}
