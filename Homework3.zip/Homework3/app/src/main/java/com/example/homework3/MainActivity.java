package com.example.homework3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Create DataBase here
        File studentDBFile = this.getDatabasePath("StudentDB");
        SQLiteDatabase db = SQLiteDatabase.openOrCreateDatabase(studentDBFile, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS Student (FirstName TEXT, LastName TEXT, SID INTEGER)");
        db.execSQL("CREATE TABLE IF NOT EXISTS Course (CourseId TEXT, Grade TEXT)");


        LinearLayout layout = new LinearLayout(this);
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        layout.setLayoutParams(params);
        layout.setOrientation(LinearLayout.VERTICAL);

        Button addStudent = new Button(this);
        addStudent.setText("Add Student");
        addStudent.setGravity(Gravity.CENTER);

        Button addCourse = new Button(this);
        addCourse.setText("Add Course");

        layout.addView(addStudent);
        layout.addView(addCourse);

        addStudent.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View view){
                        Intent intent = new Intent(view.getContext(), StudentSummary.class);
                        //String message = "message";
                        view.getContext().startActivity(intent);

                    }
                }
        );

        addCourse.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View view){
                        Intent intent = new Intent(view.getContext(), CourseSummary.class);
                        //String message = "message";
                        view.getContext().startActivity(intent);

                    }
                }
        );

        Cursor s = db.query("Student", null, null, null, null, null, null); // cursor for student DB
        // using this cursor to store values from the DB to student objects
        // and then print the students in the DB to the screen

        Student student = new Student("Test","Test", 0000);
        TextView tv = new TextView(this);
        tv.setText("Students:");
        tv.setTypeface(null, Typeface.BOLD);
        layout.addView(tv);

        if(s.getCount() > 0){   //create student objects if data exists in table
            while(s.moveToNext()){
                student = new Student(s.getString(s.getColumnIndex("FirstName")), s.getString(s.getColumnIndex("LastName")), s.getInt(s.getColumnIndex("SID")));
                tv = new TextView(this);
                tv.setText(student.getFirstName() + " " + student.getLastName() + " " + student.getID());
                layout.addView(tv);
            }
        }

        Cursor c = db.query("Course", null, null, null, null, null, null);
        Course course = new Course("Test", "Test");
        tv = new TextView(this);
        tv.setText("Courses:");
        tv.setTypeface(null, Typeface.BOLD);
        layout.addView(tv);

        if(c.getCount() > 0){
            while(c.moveToNext()){
                course = new Course(c.getString(c.getColumnIndex("CourseId")), c.getString(c.getColumnIndex("Grade")));
                tv = new TextView(this);
                tv.setText(course.getCourseID() + " " + course.getGrade());
                layout.addView(tv);
            }
        }
        db.close();

        setContentView(layout);
    }
}
